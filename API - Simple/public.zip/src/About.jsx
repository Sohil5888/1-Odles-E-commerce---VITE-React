import React from 'react';

const About = () => {
    return ( 
        <>
            <h1 className='text-2xl text-center bg-slate-300 text-black py-1 items-center'>This is my About Page</h1>
        </>
     );
}
 
export default About;