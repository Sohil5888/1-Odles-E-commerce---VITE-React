import React from 'react';
import { NavLink } from 'react-router-dom';

const Intro = () => {
    return ( 
        <>
            <h1 className='text-center text-xl'>Intro</h1>
        </>
     );
}
 
export default Intro;