import React from 'react';

const Home = () => {
    return (
        <>
            <div className="container">
                <h1 className='text-2xl text-center bg-yellow-300 text-black py-1 items-center'>This is my Home page</h1>
            </div>
        </>
    );
}

export default Home;